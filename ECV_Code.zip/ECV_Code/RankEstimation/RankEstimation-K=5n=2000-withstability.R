rm(list=ls())
require(doParallel)



source("LeiFunc-Final.R")
source("SimonFunk.R")
source("RandomHoldout.R")
source("ArashGen.R")


registerDoParallel(cores=25)


set.seed(50)


result <- foreach(ss=1:25) %dopar%{

n <- 2000#n.seq[ss]

ECV.select.seq.auc.avg <- ECV.select.seq.impute.avg <- ECV.select.seq.auc.stable <- ECV.select.seq.impute.stable <- ECV.select.seq.auc <-  ECV.select.seq.impute  <- rep(0,8)
NCV.loglike.mat <- ECV.loglike.mat <- ECV.AUC.mat <- ECV.SSE.mat <- NULL

set.seed(999+ss)
for(T in 1:8){
    A <- GenericDirectedLowRank(n=n,K=5)
    tmp.auc.K <- tmp.sse.K <- rep(0,20)
    for(k in 1:20){
        random.est <- ECV.directed.Rank(A,8,B=3,holdout.p=0.33^2,soft=FALSE)
        tmp.auc.K[k] <- which.max(random.est$auc)
        tmp.sse.K[k] <- which.min(random.est$sse)
    }
    ECV.select.seq.auc[T] <- tmp.auc.K[1]
    ECV.select.seq.impute[T] <- tmp.sse.K[1]
    ECV.select.seq.auc.avg[T] <- round(mean(tmp.auc.K))
    ECV.select.seq.impute.avg[T] <- round(mean(tmp.sse.K))
    tmp.table <- table(tmp.auc.K)
    ECV.select.seq.auc.stable[T] <- as.numeric(names(tmp.table)[which.max(tmp.table)])
    tmp.table <- table(tmp.sse.K)
    ECV.select.seq.impute.stable[T] <- as.numeric(names(tmp.table)[which.max(tmp.table)])
    }

tmp <- list(ECV.impute=ECV.select.seq.impute,ECV.auc=ECV.select.seq.auc,ECV.impute.stable=ECV.select.seq.impute.stable,ECV.impute.avg=ECV.select.seq.impute.avg,ECV.auc.stable=ECV.select.seq.auc.stable,ECV.auc.avg=ECV.select.seq.auc)


}


save(result,file="Rev1-LowRankEstimate-Directed-n2000-K=5-Stable.Rda")

