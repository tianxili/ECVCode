#source("RandomHoldout-Graphon.R")
library(doParallel)
registerDoParallel(cores=8)

source("ArashGen.R")

source("SimonFunk.R")


ZhangEst <- function(A,h=NULL){
    n <- nrow(A)
    A2 <- A%*%A/n
    if(is.null(h)){
        h <- sqrt(log(n)/n)
    }
    Kmat <- D <- matrix(0,n,n)
    for(k in 1:n){
        tmp <- abs(A2 - A2[,k])
        tmp.d <- apply(tmp,2,max)
        Kmat[k,which(tmp.d < quantile(tmp.d,h))] <- 1
    }
    Kmat <- Kmat/(rowSums(Kmat)+1e-10)
    Phat <- Kmat%*%A
    Phat <- (Phat+t(Phat))/2
    return(Phat)

}

source("RandomHoldout-Graphon.R")



N <- 500

Ks = 3#floor(log(N))
q = 0.3/(Ks+1)
B = matrix(1,Ks, Ks) * q
B = B + diag((1:Ks)/(Ks+1) - q)
label <- rep(1:Ks,each=ceiling(N/Ks))[1:N]
Z = matrix(0,N, Ks);
Z[cbind(1:N,label)] <- 1
W <- Z%*%B%*%t(Z)


#W <- W/2
mean(colSums(W))

dim(W)

#image(t(W[N:1,]))

result <- foreach(II = 1:8)%dopar%{

set.seed(500+II)

upper.index <- which(upper.tri(W))

ECV.lowrank.min <- ECV.min <- ECV.stable <- ECV.avg <- rep(0,25)
err.mat <- matrix(0,25,10)
for(I in 1:25){


upper.index <- which(upper.tri(W))

A <- matrix(0,N,N)


rand.ind <- runif(length(upper.index))

edge.index <- upper.index[rand.ind < W[upper.index]]

A[edge.index] <- 1

A <- A + t(A)
diag(A) <- 0

#image(t(A[N:1,]))

h.seq <- sqrt(log(N)/N)*seq(0.5,5,by=0.5)

#What <- ZhangEst(A,0.2*sqrt(log(N)/N))

err.seq <- rep(0,length(h.seq))

for(k in 1:length(h.seq)){
    system.time(What <- ZhangEst(A,h=h.seq[k]))
    err.seq[k] <- norm(What-W,"F")/norm(W,"F")
}
err.mat[I,] <- err.seq

#plot(h.seq,err.seq)
#image(t(What[N:1,]),col  = gray((0:64)/64))



########

system.time(ecv.Rank <- ECV.undirected.Rank(A,ceiling(sqrt(N)/2),B=15,holdout.p=0.1))

K.hat <- 3#which.min(ecv.Rank$sse)

system.time(ecv.lowrank <- EdgeCV.graphon.lowrank(A,h.seq,B=3,holdout.p=0.1,K=K.hat,fast=TRUE))

ECV.lowrank.min[I] <- which.min(colMeans(ecv.lowrank))

}

tmp.result <- list(err.mat=err.mat,ECV.lowrank.min=ECV.lowrank.min)

}


save(result,file="GraphonTuneBlock.Rda")

