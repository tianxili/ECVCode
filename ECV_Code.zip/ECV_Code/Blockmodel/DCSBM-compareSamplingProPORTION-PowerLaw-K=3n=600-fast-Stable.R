rm(list=ls())
require(doParallel)



source("LeiFunc-Final.R")
source("SimonFunk.R")
source("RandomHoldout.R")
source("ArashGenTest.R")
source("BHMC.R")
source("LRT.R")

registerDoParallel(cores=24)

p.seq <- rep(c(seq(0.02,0.2,by=0.02),0.25,0.3),2)

set.seed(50)

load("DCSBM-Degree.Rda")

result <- foreach(ss=1:24) %dopar%{

    p.value <- p.seq[ss]

NCV.dc.l2.avg <- NCV.dc.loglike.avg <- NCV.l2.avg <- NCV.loglike.avg <- ECV.sse.avg <- ECV.l2.avg <- ECV.dc.l2.avg <- ECV.loglike.avg <- ECV.dc.loglike.avg <- ECV.auc.avg <- ECV.l2.stable <- ECV.dc.l2.stable <- ECV.loglike.stable <- ECV.dc.loglike.stable <- ECV.auc.stable <- ECV.sse.stable <- NCV.l2.stable <- NCV.dc.l2.stable <- NCV.loglike.stable <- NCV.dc.loglike.stable <- vlh.SBM <- vlh.DCSBM <- BHMC <- NCV.dc.l2 <- ECV.dc.l2 <- NCV.select.l2.seq <- ECV.select.l2.seq <- NCV.dc.loglike <- ECV.dc.loglike <- NCV.impute.seq <- NCV.auc.seq <- ECV.noEdge.seq <- NCV.noEdge.seq <- ECV.select.seq.auc <- NCV.full.select.seq <- ECV2.select.seq.loglike <- ECV2.select.seq.impute <- ECV.select.seq.loglike <- ECV.select.seq.impute <- NCV.select.seq <- rep(0,100)
ECV.dc.l2.test <- ECV.dc.test <- NCV.dc.l2.test <- NCV.dc.test <- ECV.l2.model.stable <- ECV.loglike.model.stable <- NCV.l2.model.stable <- NCV.loglike.model.stable <- rep("",100)
NCV.loglike.mat <- ECV.loglike.mat <- ECV.AUC.mat <- NULL
ncv.list <- ecv.list <- list()
set.seed(500+ss)
for(T in 1:100){
    A <- ArashSBM(15,600,K=3,beta=0.2,rho=0.9,simple=FALSE,power=TRUE,degree.seed=degree.seed)
#### NCV part
    NCV.est.list <- list()
    tmp.NCV.dc.l2 <- tmp.NCV.l2 <- tmp.NCV.dc.loglike <- tmp.NCV.loglike <- rep(0,20)
    tmp.NCV.l2.model <- tmp.NCV.loglike.model <- rep("",20)
 ### ECV part
    ECV.est.list <- list()
    tmp.ECV.loglike <- tmp.ECV.l2 <- tmp.ECV.dc.loglike <- tmp.ECV.dc.l2 <- tmp.ECV.auc <- tmp.ECV.sse <- rep(0,20)
    tmp.ECV.l2.model <- tmp.ECV.loglike.model <- rep("",20)
    for(i in 1:20){
            random.est <- EdgeCV.fast.all(A,8,B=3,holdout.p=p.value,soft=FALSE,fast=TRUE,dc.est=2)
            ECV.est.list[[i]] <- random.est
            tmp.ECV.loglike[i] <- which.min(random.est$loglike)
            tmp.ECV.dc.loglike[i] <- which.min(random.est$dc.loglike)
            tmp.ECV.l2[i] <- which.min(random.est$block.err)
            tmp.ECV.dc.l2[i] <- which.min(random.est$dc.block.err)
            tmp.ECV.auc[i] <- which.max(random.est$auc)
            tmp.ECV.sse[i] <- which.min(random.est$impute.err)
        dev.model <- paste("SBM",tmp.ECV.loglike[i],sep="-")
        if(min(random.est$dc.loglike)<min(random.est$loglike)) {
            dev.model <- paste("DCSBM",which.min(random.est$dc.loglike),sep="-")
        }
        tmp.ECV.loglike.model[i] <- dev.model
        l2.model <- paste("SBM",tmp.ECV.l2[i],sep="-")
        if(min(random.est$dc.block.err)<min(random.est$block.err)) {
            l2.model <- paste("DCSBM",which.min(random.est$dc.block.err),sep="-")
        }
        tmp.ECV.l2.model[i] <- l2.model
    }
    random.est <- ECV.est.list[[1]]
    ECV.select.seq.loglike[T] <- which.min(random.est$loglike)
    ECV.select.l2.seq[T] <- which.min(random.est$block.err)
    ECV.dc.l2[T] <- which.min(random.est$dc.block.err)
    ECV.loglike.mat <- rbind(ECV.loglike.mat,random.est$loglike)
    ECV.select.seq.impute[T] <- which.min(random.est$impute)
    ECV.select.seq.auc[T] <- which.max(random.est$auc[-1])+1
    ECV.AUC.mat <- rbind(ECV.AUC.mat,random.est$auc)
    ECV.noEdge.seq[T] <- sum(random.est$no.edge.seq)
    ECV.dc.loglike[T] <- which.min(random.est$dc.loglike)
    ECV.dc.test[T] <- tmp.ECV.loglike.model[1]
    ECV.dc.l2.test[T] <- tmp.ECV.l2.model[1]
### stable version
    tmp.table <- table(tmp.ECV.loglike)
    ECV.loglike.stable[T] <- as.numeric(names(tmp.table)[which.max(tmp.table)])
    ECV.loglike.avg[T] <- round(mean(tmp.ECV.loglike)-1e-5)
    tmp.table <- table(tmp.ECV.l2)
    ECV.l2.stable[T] <- as.numeric(names(tmp.table)[which.max(tmp.table)])
    ECV.l2.avg[T] <- round(mean(tmp.ECV.l2)-1e-5)
    tmp.table <- table(tmp.ECV.dc.loglike)
    ECV.dc.loglike.stable[T] <- as.numeric(names(tmp.table)[which.max(tmp.table)])
    ECV.dc.loglike.avg[T] <- round(mean(tmp.ECV.dc.loglike)-1e-5)
    tmp.table <- table(tmp.ECV.dc.l2)
    ECV.dc.l2.stable[T] <- as.numeric(names(tmp.table)[which.max(tmp.table)])
    ECV.dc.l2.avg[T] <- round(mean(tmp.ECV.dc.l2)-1e-5)
    tmp.table <- table(tmp.ECV.auc)
    ECV.auc.stable[T] <- as.numeric(names(tmp.table)[which.max(tmp.table)])
    ECV.auc.avg[T] <- round(mean(tmp.ECV.auc)-1e-5)
    tmp.table <- table(tmp.ECV.sse)
    ECV.sse.stable[T] <- as.numeric(names(tmp.table)[which.max(tmp.table)])
    ECV.sse.avg[T] <- round(mean(tmp.ECV.auc)-1e-5)
    tmp.table <- table(tmp.ECV.l2.model)
    ECV.l2.model.stable[T] <- names(tmp.table)[which.max(tmp.table)]
    tmp.table <- table(tmp.ECV.loglike.model)
    ECV.loglike.model.stable[T] <- names(tmp.table)[which.max(tmp.table)]

}

tmp <- list(NCV=NCV.select.seq,ECV.loglike=ECV.select.seq.loglike,ECV.impute=ECV.select.seq.impute,ECV.auc=ECV.select.seq.auc,ECV.noEdge.seq=ECV.noEdge.seq,NCV.noEdge.seq=NCV.noEdge.seq,NCV.dc.loglike=NCV.dc.loglike,ECV.dc.loglike=ECV.dc.loglike,NCV.dc.test=NCV.dc.test,ECV.dc.test=ECV.dc.test,NCV.dc.l2=NCV.dc.l2,ECV.dc.l2=ECV.dc.l2,NCV.l2=NCV.select.l2.seq,ECV.l2=ECV.select.l2.seq,NCV.dc.l2.test=NCV.dc.l2.test,ECV.dc.l2.test=ECV.dc.l2.test,BHMC=BHMC,vlh.DCSBM=vlh.DCSBM,
            ECV.sse.avg=ECV.sse.avg, ECV.l2.avg= ECV.l2.avg, ECV.dc.l2.avg=ECV.dc.l2.avg, ECV.loglike.avg=ECV.loglike.avg, ECV.dc.loglike.avg=ECV.dc.loglike.avg, ECV.auc.avg=ECV.auc.avg, ECV.l2.stable=ECV.l2.stable,ECV.dc.l2.stable=ECV.dc.l2.stable, ECV.loglike.stable=ECV.loglike.stable, ECV.dc.loglike.stable=ECV.dc.loglike.stable, ECV.l2.model.stable=ECV.l2.model.stable, ECV.loglike.model.stable=ECV.loglike.model.stable, ECV.auc.stable=ECV.auc.stable, ECV.sse.stable=ECV.sse.stable, NCV.l2.stable=NCV.l2.stable,NCV.dc.l2.stable=NCV.dc.l2.stable, NCV.loglike.stable=NCV.loglike.stable,NCV.dc.loglike.stable=NCV.dc.loglike.stable, NCV.l2.model.stable=NCV.l2.model.stable,NCV.loglike.model.stable=NCV.loglike.model.stable,NCV.l2.avg=NCV.l2.avg,NCV.loglike.avg=NCV.loglike.avg,NCV.dc.l2.avg=NCV.dc.l2.avg,NCV.dc.loglike.avg=NCV.dc.loglike.avg)


}


save(result,file="Final-DCSBM-SamplingProportion-PowerLaw-K=3n=600-Raw-fast-withstability.Rda")
