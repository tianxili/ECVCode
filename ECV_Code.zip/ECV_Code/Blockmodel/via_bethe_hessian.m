function [k] = via_bethe_hessian(A,eig_num)
% BHa method
% A - the adjacency matrix
% eig_num - the number of eigenvalues computed
n = size(A,1); 
d = sum(A,1); 
r = sqrt(mean(d));
H = (r*r - 1)*eye(n) - r*A + diag(d);
[~,D] = eigs(H,eig_num,'sa');
k = sum(sum(D,1)<0);
end
