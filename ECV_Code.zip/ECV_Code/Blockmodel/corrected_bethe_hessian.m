function [k] = corrected_bethe_hessian(A,eig_num,tuning_par)
% BHmc
n = size(A,1); 
d = sum(A,1); 

r = sqrt(mean(d.*d)/mean(d)-1);
H = (r*r-1)*eye(n) - r*A + diag(d);
[~,D] = eigs(H,eig_num,'sa'); eigval = sort(sum(D,1),'ascend');
k = 1;
for i = 1:eig_num-1
    if tuning_par*eigval(i) < eigval(i+1)
        k = i;
    end
end
%eigenvalue(eigval);
%eig_cdf(eigval)
end