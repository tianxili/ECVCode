function [k] = corrected_bethe_hessian_average_degree(A,eig_num,tuning_par)
% BHac
n = size(A,1); 
d = sum(A,1); 
r = sqrt(mean(d));
H = (r*r - 1)*eye(n) - r*A + diag(d);
[~,D] = eigs(H,eig_num,'sa'); eigval = sort(sum(D,1),'ascend');
%eig_cdf(eigval)
k = 1;
for i = 1:eig_num-1
    if tuning_par*eigval(i) < eigval(i+1)
        k = i;
    end
end
end