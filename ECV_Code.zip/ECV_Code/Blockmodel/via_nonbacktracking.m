function [k,r] = via_nonbacktracking(A,eig_num)
% NB method
n = size(A,1); d = sum(A,1); tolerance = 10^(-5);

B = [zeros(n), diag(d-1); -eye(n), A]; % non-backtracking matrix
[~,D] = eigs(B,eig_num,'lr'); eigval = diag(D); 

eigval_R = real(eigval); eigval_E = imag(eigval); 

threshold = sqrt(eigval_R(1));%max(eigval_R((eigval_E ~= 0)));

%bulk_radius = sqrt(mean(d));

k = sum((eigval_R > threshold) & (abs(eigval_E) < tolerance )); r = threshold;

% subplot(2,1,1)
% scatter(eigval_R,eigval_E,'.')
end
function [Ein,Eout] = non_backtracking_labels(A)
n = size(A,1); d = sum(A,1);

B = [zeros(n), diag(d-1); -eye(n), A]; % non-backtracking matrix
[U,D] = eigs(B,10,'lm');
Ein = (sign(U(1:n,2)) + 3)/2;
Eout = (sign(U(n+1:2*n,2)) + 3)/2;

% eigval = diag(D); 
% eigval_R = real(eigval); eigval_E = imag(eigval);
% [~,id] = sort(eigval_R,'descend');
% scatter(eigval_R,eigval_E,'.','b'); daspect([1 1 1]); hold all;
% scatter(eigval_R(id(1:2)),eigval_E(id(1:2)),'r'); hold off;
end
function [] = non_backtracking_spectrum(A,k)
n = size(A,1); 
d = sum(A,2);
B = [zeros(n), diag(d)-eye(n); -eye(n), full(A)];
[~,D] = eig(B);
eig_real = real(sum(D,1)); eig_imag = imag(sum(D,1)); 
scatter(eig_real,eig_imag,'.','b'); hold all;
[~,id] = sort(eig_real,'descend');
for i = 1:k
    scatter(eig_real(id(i)),eig_imag(id(i)),'b','filled'); hold all;
end
r = sqrt(eig_real(id(1)));
rectangle('Position',[-r,-r,2*r,2*r],...
          'EdgeColor','r',...
          'LineWidth',1,...
          'Curvature',[1,1]);
hold off;
daspect([1 1 1]);
end
