rm(list=ls())
require(doParallel)



source("LeiFunc-Final.R")
source("SimonFunk.R")
source("RandomHoldout.R")
source("ArashGenTest.R")
source("BHMC.R")
source("LRT.R")

registerDoParallel(cores=24)

#lambda.seq <- rep(c(15,25,35,45),8)
t.seq <- rep(c(0,0.25,0.5,1),8)

set.seed(50)

load("DCSBM-Degree.Rda")

result <- foreach(ss=1:32) %dopar%{

#lambda <- lambda.seq[ss]
t.value <- t.seq[ss]

NCV.dc.l2.avg <- NCV.dc.loglike.avg <- NCV.l2.avg <- NCV.loglike.avg <- ECV.sse.avg <- ECV.l2.avg <- ECV.dc.l2.avg <- ECV.loglike.avg <- ECV.dc.loglike.avg <- ECV.auc.avg <- ECV.l2.stable <- ECV.dc.l2.stable <- ECV.loglike.stable <- ECV.dc.loglike.stable <- ECV.auc.stable <- ECV.sse.stable <- NCV.l2.stable <- NCV.dc.l2.stable <- NCV.loglike.stable <- NCV.dc.loglike.stable <- vlh.SBM <- vlh.DCSBM <- BHMC <- NCV.dc.l2 <- ECV.dc.l2 <- NCV.select.l2.seq <- ECV.select.l2.seq <- NCV.dc.loglike <- ECV.dc.loglike <- NCV.impute.seq <- NCV.auc.seq <- ECV.noEdge.seq <- NCV.noEdge.seq <- ECV.select.seq.auc <- NCV.full.select.seq <- ECV2.select.seq.loglike <- ECV2.select.seq.impute <- ECV.select.seq.loglike <- ECV.select.seq.impute <- NCV.select.seq <- rep(0,25)
ECV.dc.l2.test <- ECV.dc.test <- NCV.dc.l2.test <- NCV.dc.test <- ECV.l2.model.stable <- ECV.loglike.model.stable <- NCV.l2.model.stable <- NCV.loglike.model.stable <- rep("",25)
NCV.loglike.mat <- ECV.loglike.mat <- ECV.AUC.mat <- NULL
ncv.list <- ecv.list <- list()
set.seed(500+ss)
for(T in 1:25){
    A <- ArashSBM(40,600,K=5,beta=0.2,Pi=(1:5)^t.value/sum((1:5)^t.value))

### NCV part
    NCV.est.list <- list()
    tmp.NCV.dc.l2 <- tmp.NCV.l2 <- tmp.NCV.dc.loglike <- tmp.NCV.loglike <- rep(0,20)
    tmp.NCV.l2.model <- tmp.NCV.loglike.model <- rep("",20)
    for(i in 1:20){
        NCV.est.list[[i]] <- NCV.select(A,8,cv=3)
        NCV.est <- NCV.est.list[[i]]
        tmp.NCV.loglike[i] <- which.min(NCV.est$loglike)
        tmp.NCV.dc.loglike[i] <- which.min(NCV.est$dc.loglike)
        tmp.NCV.l2[i] <- which.min(NCV.est$SE)
        tmp.NCV.dc.l2[i] <- which.min(NCV.est$dc.SE)
        dev.model <- paste("SBM",tmp.NCV.loglike[i],sep="-")
        if(min(NCV.est$dc.loglike)<min(NCV.est$loglike)) {
            dev.model <- paste("DCSBM",which.min(NCV.est$dc.loglike),sep="-")
        }
        tmp.NCV.loglike.model[i] <- dev.model
        l2.model <- paste("SBM",tmp.NCV.l2[i],sep="-")
        if(min(NCV.est$dc.SE)<min(NCV.est$SE)) {
            l2.model <- paste("DCSBM",which.min(NCV.est$dc.SE),sep="-")
        }
        tmp.NCV.l2.model[i] <- l2.model
    }
    NCV.est <- NCV.est.list[[1]]
    NCV.select.seq[T] <- which.min(NCV.est$loglike)
    NCV.select.l2.seq[T] <- which.min(NCV.est$SE)
    NCV.dc.l2[T] <- which.min(NCV.est$dc.SE)
    NCV.dc.loglike[T] <- which.min(NCV.est$dc.loglike)
    NCV.dc.test[T] <- tmp.NCV.loglike.model[1]
    NCV.dc.l2.test[T] <- tmp.NCV.l2.model[1]
    #### stable NCV part
    tmp.table <- table(tmp.NCV.loglike)
    NCV.loglike.stable[T] <- as.numeric(names(tmp.table)[which.max(tmp.table)])
    NCV.loglike.avg[T] <- round(mean(tmp.NCV.loglike))
    tmp.table <- table(tmp.NCV.l2)
    NCV.l2.stable[T] <- as.numeric(names(tmp.table)[which.max(tmp.table)])
    NCV.l2.avg[T] <- round(mean(tmp.NCV.l2))
    tmp.table <- table(tmp.NCV.dc.loglike)
    NCV.dc.loglike.stable[T] <- as.numeric(names(tmp.table)[which.max(tmp.table)])
    NCV.dc.loglike.avg[T] <- round(mean(tmp.NCV.dc.loglike))
    tmp.table <- table(tmp.NCV.dc.l2)
    NCV.dc.l2.stable[T] <- as.numeric(names(tmp.table)[which.max(tmp.table)])
    NCV.dc.l2.avg[T] <- round(mean(tmp.NCV.dc.l2))
    tmp.table <- table(tmp.NCV.l2.model)
    NCV.l2.model.stable[T] <- names(tmp.table)[which.max(tmp.table)]
    tmp.table <- table(tmp.NCV.loglike.model)
    NCV.loglike.model.stable[T] <- names(tmp.table)[which.max(tmp.table)]


 ### ECV part
    ECV.est.list <- list()
    tmp.ECV.loglike <- tmp.ECV.l2 <- tmp.ECV.dc.loglike <- tmp.ECV.dc.l2 <- tmp.ECV.auc <- tmp.ECV.sse <- rep(0,20)
    tmp.ECV.l2.model <- tmp.ECV.loglike.model <- rep("",20)
    for(i in 1:20){
            random.est <- EdgeCV.fast.all(A,8,B=3,holdout.p=0.33^2,soft=FALSE,fast=TRUE,dc.est=2)
            ECV.est.list[[i]] <- random.est
            tmp.ECV.loglike[i] <- which.min(random.est$loglike)
            tmp.ECV.dc.loglike[i] <- which.min(random.est$dc.loglike)
            tmp.ECV.l2[i] <- which.min(random.est$block.err)
            tmp.ECV.dc.l2[i] <- which.min(random.est$dc.block.err)
            tmp.ECV.auc[i] <- which.max(random.est$auc)
            tmp.ECV.sse[i] <- which.min(random.est$impute.err)
        dev.model <- paste("SBM",tmp.ECV.loglike[i],sep="-")
        if(min(random.est$dc.loglike)<min(random.est$loglike)) {
            dev.model <- paste("DCSBM",which.min(random.est$dc.loglike),sep="-")
        }
        tmp.ECV.loglike.model[i] <- dev.model
        l2.model <- paste("SBM",tmp.ECV.l2[i],sep="-")
        if(min(random.est$dc.block.err)<min(random.est$block.err)) {
            l2.model <- paste("DCSBM",which.min(random.est$dc.block.err),sep="-")
        }
        tmp.ECV.l2.model[i] <- l2.model
    }
    random.est <- ECV.est.list[[1]]
    ECV.select.seq.loglike[T] <- which.min(random.est$loglike)
    ECV.select.l2.seq[T] <- which.min(random.est$block.err)
    ECV.dc.l2[T] <- which.min(random.est$dc.block.err)
    ECV.loglike.mat <- rbind(ECV.loglike.mat,random.est$loglike)
    ECV.select.seq.impute[T] <- which.min(random.est$impute)
    ECV.select.seq.auc[T] <- which.max(random.est$auc[-1])+1
    ECV.AUC.mat <- rbind(ECV.AUC.mat,random.est$auc)
    ECV.noEdge.seq[T] <- sum(random.est$no.edge.seq)
    ECV.dc.loglike[T] <- which.min(random.est$dc.loglike)
    ECV.dc.test[T] <- tmp.ECV.loglike.model[1]
    ECV.dc.l2.test[T] <- tmp.ECV.l2.model[1]
### stable version
    tmp.table <- table(tmp.ECV.loglike)
    ECV.loglike.stable[T] <- as.numeric(names(tmp.table)[which.max(tmp.table)])
    ECV.loglike.avg[T] <- round(mean(tmp.ECV.loglike)-1e-5)
    tmp.table <- table(tmp.ECV.l2)
    ECV.l2.stable[T] <- as.numeric(names(tmp.table)[which.max(tmp.table)])
    ECV.l2.avg[T] <- round(mean(tmp.ECV.l2)-1e-5)
    tmp.table <- table(tmp.ECV.dc.loglike)
    ECV.dc.loglike.stable[T] <- as.numeric(names(tmp.table)[which.max(tmp.table)])
    ECV.dc.loglike.avg[T] <- round(mean(tmp.ECV.dc.loglike)-1e-5)
    tmp.table <- table(tmp.ECV.dc.l2)
    ECV.dc.l2.stable[T] <- as.numeric(names(tmp.table)[which.max(tmp.table)])
    ECV.dc.l2.avg[T] <- round(mean(tmp.ECV.dc.l2)-1e-5)
    tmp.table <- table(tmp.ECV.auc)
    ECV.auc.stable[T] <- as.numeric(names(tmp.table)[which.max(tmp.table)])
    ECV.auc.avg[T] <- round(mean(tmp.ECV.auc)-1e-5)
    tmp.table <- table(tmp.ECV.sse)
    ECV.sse.stable[T] <- as.numeric(names(tmp.table)[which.max(tmp.table)])
    ECV.sse.avg[T] <- round(mean(tmp.ECV.auc)-1e-5)
    tmp.table <- table(tmp.ECV.l2.model)
    ECV.l2.model.stable[T] <- names(tmp.table)[which.max(tmp.table)]
    tmp.table <- table(tmp.ECV.loglike.model)
    ECV.loglike.model.stable[T] <- names(tmp.table)[which.max(tmp.table)]




    ncv.list[[T]] <- NCV.est.list
    ecv.list[[T]] <- ECV.est.list
    BHMC[T] <- BHMC.estimate(A)$K
    vlh <- LRT(A,8,model="SBM")
    vlh.SBM[T] <- vlh$SBM.K

}

tmp <- list(NCV=NCV.select.seq,ECV.loglike=ECV.select.seq.loglike,ECV.impute=ECV.select.seq.impute,ECV.auc=ECV.select.seq.auc,ECV.noEdge.seq=ECV.noEdge.seq,NCV.noEdge.seq=NCV.noEdge.seq,NCV.dc.loglike=NCV.dc.loglike,ECV.dc.loglike=ECV.dc.loglike,NCV.dc.test=NCV.dc.test,ECV.dc.test=ECV.dc.test,NCV.dc.l2=NCV.dc.l2,ECV.dc.l2=ECV.dc.l2,NCV.l2=NCV.select.l2.seq,ECV.l2=ECV.select.l2.seq,NCV.dc.l2.test=NCV.dc.l2.test,ECV.dc.l2.test=ECV.dc.l2.test,BHMC=BHMC,vlh.SBM=vlh.SBM,
            ECV.sse.avg=ECV.sse.avg, ECV.l2.avg= ECV.l2.avg, ECV.dc.l2.avg=ECV.dc.l2.avg, ECV.loglike.avg=ECV.loglike.avg, ECV.dc.loglike.avg=ECV.dc.loglike.avg, ECV.auc.avg=ECV.auc.avg, ECV.l2.stable=ECV.l2.stable,ECV.dc.l2.stable=ECV.dc.l2.stable, ECV.loglike.stable=ECV.loglike.stable, ECV.dc.loglike.stable=ECV.dc.loglike.stable, ECV.l2.model.stable=ECV.l2.model.stable, ECV.loglike.model.stable=ECV.loglike.model.stable, ECV.auc.stable=ECV.auc.stable, ECV.sse.stable=ECV.sse.stable, NCV.l2.stable=NCV.l2.stable,NCV.dc.l2.stable=NCV.dc.l2.stable, NCV.loglike.stable=NCV.loglike.stable,NCV.dc.loglike.stable=NCV.dc.loglike.stable, NCV.l2.model.stable=NCV.l2.model.stable,NCV.loglike.model.stable=NCV.loglike.model.stable,NCV.l2.avg=NCV.l2.avg,NCV.loglike.avg=NCV.loglike.avg,NCV.dc.l2.avg=NCV.dc.l2.avg,NCV.dc.loglike.avg=NCV.dc.loglike.avg)


}


save(result,file="Final-SBM-Pi-PowerLaw-K=5n=600-Raw-fast-withstability.Rda")
