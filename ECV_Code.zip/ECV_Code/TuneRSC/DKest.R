source("ArashGen-SP.R")
#source("RandomHoldout-FinalSP.R")
source("SP.R")
library(irlba)




DKest.Arash.orig <- function(A,K,tau.seq){
    m <- length(tau.seq)
    result <- rep(0,m)
    #A <- A+1e-6
    for(k in 1:m){
        tau <- tau.seq[k]
        d.vec <- colSums(A)
        n <- nrow(A)
        true.tau <- tau*mean(d.vec)/n
        A.tau <- A+true.tau
        d.vec.tau <- colSums(A.tau)
        D.tau.inv.sqrt <- diag(1/sqrt(d.vec.tau))
        L.tau <- D.tau.inv.sqrt%*%A.tau%*%D.tau.inv.sqrt
        m1 <- Arash.reg.SSP(A=A,K=K,tau=tau.seq[k],lap=TRUE)

        B <- matrix(0,K,K)
        Psi <- rep(0,n)
        #Psi.outer <- outer(Psi,Psi)
        Theta <- matrix(0,n,K)
        for(i in 1:K){
            for(j in i:K){
                N.i <- which(m1$cluster==i)
                N.j <- which(m1$cluster==j)
                B[i,j] <- B[j,i] <- sum(A[N.i,N.j],na.rm=TRUE)+1e-3
            }
            Theta[N.i,i] <- 1
        }

        Psi <- colSums(A,na.rm=TRUE)
            #print(Psi)
        B.rowSums <- rowSums(B)
        B.g <- Theta%*%B.rowSums
        Psi <- as.numeric(Psi/B.g)
            #print(Psi)
        tmp.mat <- Theta*Psi
        P.hat <- tmp.mat%*%B%*%t(tmp.mat)
            #print(dim(Psi))
        diag(P.hat) <- 0

        P.hat.tau <- P.hat+true.tau
        #d.hat.tau <- colSums(P.hat.tau) ### estimated population D
        d.hat.tau <- d.vec.tau# + true.tau ### observed D, in the paper, this is used though seems the estimated D is more reasonable. The two give similar results.
        D.hat.tau.inv.sqrt <- diag(1/sqrt(d.hat.tau))
        L.hat.tau <- t(t(P.hat.tau/sqrt(d.hat.tau))/sqrt(d.hat.tau))#D.hat.tau.inv.sqrt%*%P.hat.tau%*%D.hat.tau.inv.sqrt
        L.hat.eigen <- irlba(L.hat.tau,nv=K)
        mu.K <- L.hat.eigen$d[K]
        result[k] <- irlba(L.tau-L.hat.tau,2)$d[1]/abs(mu.K)
    }
    return(result)
}





