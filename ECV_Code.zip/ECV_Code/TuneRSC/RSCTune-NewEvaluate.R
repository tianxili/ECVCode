rm(list=ls())
require(doParallel)

source("ArashGen-SP.R")
source("RandomHoldout-FinalSP.R")
source("SP.R")
source("DKest.R")

source("evaluate_estimation.R")


load("DCSBM-Degree.Rda")


registerDoParallel(cores=20)

set.seed(999)
tau.seq <- c(0.00001,seq(0.1,2,by=0.1))
N <- 600
result <- foreach(ss=1:20) %dopar%{

set.seed(99+ss)
cv.err <- rep(0,10)
gap.mat <-  partial.mat2 <- dk.mat  <- acc.mat <- acc2.mat <- matrix(0,10,21)
gap.new <- partial.new <- gap.new.min.stable <- partial.new.max.stable <- gap.new.min.avg <- partial.new.max.avg <- rep(0,10)
gap.new2 <- partial.new2 <- gap.new.min.stable2 <- partial.new.max.stable2 <- gap.new.min.avg2 <- partial.new.max.avg2 <- rep(0,10)
gap.new3 <- partial.new3 <- gap.new.min.stable3 <- partial.new.max.stable3 <- gap.new.min.avg3 <- partial.new.max.avg3 <- rep(0,10)

for(i in 1:10){
   set.seed(99+ss+i)
    dd <- ArashSBM.full(lambda=5,n=N,K=3,beta=0.2,rho=0.9,simple=FALSE,power=TRUE)
acc2.seq <- acc.seq <- err.seq <- rep(0,11)


for(k in 1:21){
  m1 <- Arash.reg.SSP(A=dd$A,K=3,tau=tau.seq[k],lap=TRUE)

  true.Z <- m1.Z <- matrix(0,N,3)
  m1.Z[cbind(1:N,m1$cluster)] <- 1
  true.Z[cbind(1:N,dd$g)] <- 1
  acc.seq[k] <- accuracy(m1.Z,true.Z)
  acc2.seq[k] <- NMI(g1=dd$g,g2=m1$cluster)
}

   acc.seq

system.time(tt1 <- EdgeCV.REG.DC(A=dd$A,h.seq=tau.seq,K=3,holdout.p=0.1,B=15,soft=FALSE,fast=TRUE))
system.time(tt2 <- EdgeCV.REG.DC.backtracking(A=dd$A,h.seq=tau.seq,K=3,holdout.p=0.1,B=15,soft=FALSE,fast=TRUE))
   system.time(tt3 <- EdgeCV.REG.DC.forwardtracking(A=dd$A,h.seq=tau.seq,K=3,holdout.p=0.1,B=15,soft=FALSE,fast=TRUE))
                                        #which.min(tt2$gap)
                                        #which.min(tt2$gap)

#system.time(tt1 <- EdgeCV.REG.DC.NEW(A=dd$A,h.seq=tau.seq,K=3,holdout.p=0.1,B=15,soft=FALSE,fast=TRUE))

gap.new[i] <- tt1$gap.which.min
partial.new[i] <- tt1$partial.which.max
gap.new.min.stable[i] <- tt1$gap.min.stable
gap.new.min.avg[i] <- tt1$gap.min.avg
partial.new.max.stable[i] <- tt1$partial.max.stable
partial.new.max.avg[i] <- tt1$partial.max.avg

   gap.new2[i] <- tt2$gap.which.min
   partial.new2[i] <- tt2$partial.which.max
   gap.new.min.stable2[i] <- tt2$gap.min.stable
   gap.new.min.avg2[i] <- tt2$gap.min.avg
   partial.new.max.stable2[i] <- tt2$partial.max.stable
   partial.new.max.avg2[i] <- tt2$partial.max.avg



   gap.new3[i] <- tt3$gap.which.min
   partial.new3[i] <- tt3$partial.which.max
   gap.new.min.stable3[i] <- tt3$gap.min.stable
   gap.new.min.avg3[i] <- tt3$gap.min.avg
   partial.new.max.stable3[i] <- tt3$partial.max.stable
   partial.new.max.avg3[i] <- tt3$partial.max.avg

system.time(dk <- DKest.Arash.orig(A=dd$A,K=3,tau.seq=tau.seq))
which.min(dk)


dk.mat[i,] <- dk
acc.mat[i,] <- acc.seq
acc2.mat[i,] <- acc2.seq



}
tmp <- list(acc.mat = acc.mat,acc2.mat=acc2.mat,dk.mat=dk.mat,gap.new=gap.new,partial.new=partial.new,gap.new.min.stable=gap.new.min.stable,gap.new.min.avg=gap.new.min.avg,partial.new.max.stable=partial.new.max.stable,partial.new.max.avg=partial.new.max.avg,gap.new2=gap.new2,partial.new2=partial.new2,gap.new.min.stable2=gap.new.min.stable2,gap.new.min.avg2=gap.new.min.avg2,partial.new.max.stable2=partial.new.max.stable2,partial.new.max.avg2=partial.new.max.avg2,gap.new3=gap.new3,partial.new3=partial.new3,gap.new.min.stable3=gap.new.min.stable3,gap.new.min.avg3=gap.new.min.avg3,partial.new.max.stable3=partial.new.max.stable3,partial.new.max.avg3=partial.new.max.avg3)
}


save(result,file="FinalRSCTune_NewEval.Rda")
